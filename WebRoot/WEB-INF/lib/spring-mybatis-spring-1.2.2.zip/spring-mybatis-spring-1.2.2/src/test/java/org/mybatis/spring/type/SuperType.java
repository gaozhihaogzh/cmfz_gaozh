package org.mybatis.spring.type;

public class SuperType {
}
